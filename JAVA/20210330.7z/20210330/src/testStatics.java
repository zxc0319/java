import java.util.Random;

public class testStatics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*
		int[] data = new int[10];
		
		Random rnd = new Random();
		
		for(int i=0;i<data.length;i++) {
			data[i] = rnd.nextInt(101);
		}*/
		
		//int[] data = new int[10];
		
		//Statics.initArray(data);
		
		int[] data = Statics.initArray(10);
		
		Statics.printArray(data);
		
		//System.out.println("VARIANCE = " + Statics.calVariance(data));
		
		//Statics.bubbleSort(data);
		//Statics.selectionSort(data);
		
		
		Statics.insertSort(data);
		Statics.printArray(data);
		System.out.println("25%����� = " + Statics. calPercent(25,data));
		System.out.println("�|����t = " + Statics.calIQR(data));
		
	}

}
