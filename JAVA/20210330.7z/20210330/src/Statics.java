import java.util.Random;

public class Statics {
	
	public static void initArray(int[] data) {
		
		Random rnd = new Random();
		
		for(int i=0;i<data.length;i++) {
			data[i] = rnd.nextInt(101);
		}
		
	}
	
	public static int[] initArray(int count) {
		int[] data = new int[count];
		Random rnd = new Random();
		
		for(int i=0;i<data.length;i++) {
			data[i] = rnd.nextInt(101);
		}
		
		return data;
		
	}
	
	public static void printArray(int[] data) {
		for(int i=0;i<data.length;i++) {
			System.out.print(data[i] + "\t");
			if((i%10) == 9) {
				System.out.println();
			}
		}
	}
	
	public static double calVariance(int[] data) {
		int sum = 0;
		for(int i=0;i<data.length;i++) {
			sum = sum + data[i];
		}
		double avg = (double)sum / data.length;
		System.out.println("AVG = " + avg);
		
		double s = 0;
		for(int i=0;i<data.length;i++) {
			//s = s + ((data[i]-avg) * (data[i]-avg));
			s = s + Math.pow((data[i]-avg),2);
		}
		double var = s / data.length;
		
		return var;
		
		//double std = Math.sqrt(var);
		//System.out.println("STD = " + std);
	}
	
	public static double calSD(int[] data) {
		double variance = calVariance(data);
		return Math.sqrt(variance);
	}
	
	public static int calRange(int[] data) {
		int max = data[0];
		for(int i=0;i<data.length;i++) {
			if(data[i] > max) {
				max = data[i];
			}
		}
		int min = data[0];
		for(int i=0;i<data.length;i++) {
			if(data[i] < min) {
				min = data[i];
			}
		}
		
		return (max-min);
	}
	
	public static void calMo(int[] data) {
		int[] count = new int[101];
		for(int i=0;i<data.length;i++) {	
			count[data[i]] =  count[data[i]] + 1;
		}
		int maxCount = count[0];
		for(int i=0;i<count.length;i++) {
			if(count[i] > maxCount) {
				maxCount = count[i];
			}
		}
		for(int i=0;i<count.length;i++) {
			if(count[i] == maxCount) {
				System.out.print(i + "\t");
			}
		}
	}
	
	public static void bubbleSort(int[] data) {
		int tmp;
		
		for(int i=0;i<data.length-1;i++) {
			
			for(int j =0;j<data.length-1-i;j++) {
				if(data[j] > data[j+1]) {
					tmp = data[j];
					data[j] = data[j+1];
					data[j+1] = tmp;
					
				}
			}
		}
	}
	//��ܱƧǪk
	public static void selectionSort(int[] data) {
		
		for(int i=0;i<data.length-1;i++) {
			int min=i;
			for(int j=i+1;j<data.length;j++) {
				if(data[j] < data[min]) min = j;
		        	
			}
			if(i!=min)
			{
				int tmp = data[i];
				data[i] = data[min];
				data[min] = tmp;
			}
		}
	}
	//���J�ƧǪk
	public static void insertSort(int[] data) {
		//3 1 9 4 0    1 3 9 4 0 
		for(int i=0;i<data.length-1;i++) {
			for(int j=i+1;j<data.length;j++) {
				if(data[i]>data[j])
				{
					int tmp = data[i];
					data[i] = data[j];
					data[j] = tmp;
				}
			}
		}
		
	}
	
	/*
	 * �p�⤤���
	 * ��J : �}�C
	 * ��X : �����
	 */
	public static double calMidian(int[] data) {
		
		int position = data.length / 2;
		
		double middle = 0;
		
		if(data.length%2 == 0) {
			middle = (double)(data[position-1] + data[position])/2;
		} else {
			middle = data[position];
		}
		
		
		return middle;
	}
	
	public static double calPercent(int p, int[] data) {
		// ��Xp%���
		int N=(int)Math.ceil(data.length*((double)p/100));
		return (data[(N-1+N)/2]);
	}
	
	public static double calIQR(int[] data) {
		return (Statics.calPercent(75, data)-Statics.calPercent(25, data));
	}

}
