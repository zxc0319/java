import java.util.Random;
import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in =new Scanner(System.in);
		System.out.print("�п�J���X��P��:");
		int A =in.nextInt();		
		int[] g =new int [A];
		Random RN=new Random();
		double X=0;
		
		for(int i=1;i<=g.length;i++) {
			System.out.print("��"+ i +"�즨�Z:");
			g[i-1]=RN.nextInt(101);
			System.out.print(g[i-1]+"\t");
			if(i%10==5||i%10==0) {
				System.out.println();
			}
			X += g[i-1];
		}		
		System.out.println();
		System.out.print("���Z����"+ (X/g.length));
				
		in.close();

	}

}
