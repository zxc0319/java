import java.util.Random;
import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in =new Scanner(System.in);
		System.out.print("�п�J�Ӽ�:");
		int A =in.nextInt();		
		int[] g =new int [A];
		Random RN=new Random();
		double X=0;
		double B=0;
		for(int i=1;i<=g.length;i++) {			
			g[i-1]=RN.nextInt(101);
			System.out.println(g[i-1]);
			X += g[i-1];
		}	
		//�ܲ���
		for(int i=1;i<=g.length;i++) {
			B+=(g[i-1]-(X/g.length))*(g[i-1]-(X/g.length));
		}						
		System.out.println("�ܲ���:"+B);
		//���Z
		int max,b;
		for(int i=1;i<=g.length;i++) {
		a=g[i-1];b=g[i];
		if
		}
		
		
		
		
		
		
				
		in.close();

	}

}
