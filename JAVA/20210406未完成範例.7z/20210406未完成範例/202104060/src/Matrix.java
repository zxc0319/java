import java.util.Random;

public class Matrix {
	//�H���}�C
	public static void initMatrix(int[][] data) {
		Random RN =new Random();
		for(int i=0;i<data.length;i++) {
			for(int j=0;j<data[i].length;j++) {
				data[i][j]=RN.nextInt(101);
			}
		}
	}
	//�L
	public static void printMatrix(int[][] a) {
	
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				System.out.print("["+a[i][j] + "]\t");
				
			}
			System.out.println();
		}
		System.out.println();
	}
	//�[
	public static void MatrixSum(int[][] a, int[][] b) {
		System.out.println("�[");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				System.out.print("["+(a[i][j]+b[i][j])+"]\t");
			}
			System.out.println();
			}
	}
	//��
	public static void MatrixSub(int[][] a, int[][] b) {
		System.out.println("��");
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a[i].length;j++) {
				System.out.print("["+(a[i][j]-b[i][j])+"]\t");
			}
			System.out.println();
			}
	}
	//��
	public static void MatrixMultipy(int[][] a, int[][] b) {
		
	}

}
