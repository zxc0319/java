
public class testx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] a;
		
		a = new int[4][];
		
		a[0] = new int[5];
		a[1] = new int[2];
		a[2] = new int[3];
		a[3] = new int[2];
		
		int[] b = new int[10];

	}

}
