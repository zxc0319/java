
public class testMatrix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] a = new int[2][2];
		int[][] b = new int[2][2];
		
		Matrix.initMatrix(a);
		Matrix.printMatrix(a);
		
		Matrix.initMatrix(b);
		Matrix.printMatrix(b);
		
		Matrix.MatrixSum(a, b);
		
		Matrix.MatrixSub(a, b);
		
		Matrix.MatrixMultipy(a, b);

	}

}
